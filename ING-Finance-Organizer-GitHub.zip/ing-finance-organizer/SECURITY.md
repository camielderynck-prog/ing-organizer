# Security and privacy

Never commit real bank exports, account identifiers, API keys, passwords, or personal financial data. CSV data selected in the browser is processed locally by `index.html`; it is not sent to GitHub Pages or a third-party AI provider. Report code issues without attaching real financial statements.
