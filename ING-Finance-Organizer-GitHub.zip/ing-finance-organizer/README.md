# ING Finance Organizer

Een privacyvriendelijke webapp om een **door jou gedownload ING CSV-verrichtingenbestand** te lezen, te categoriseren en overzichtelijk te maken. De app werkt lokaal in je browser. Hij logt niet in bij ING en verstuurt geen bankgegevens naar een AI-dienst.

## Snel starten

1. Download of pak dit project uit.
2. Open `index.html` in Edge, Chrome of Firefox.
3. Kies je ING-verrichtingenbestand (`.csv`).
4. Bekijk de categorieën, controles en bespaarschattingen. Corrigeer een categorie met het keuzemenu; je correctie wordt lokaal in die browser onthouden.
5. Gebruik **Download overzicht** om een nieuw gecategoriseerd CSV-bestand te bewaren.

Geen Python, installatieprogramma, account of API-sleutel nodig.

## Slimme herkenning

De app bekijkt de naam van de tegenpartij en de omschrijving met een lokale herkenningslijst. Bekende winkels en diensten (zoals supermarkten, telecom- en streamingbedrijven) krijgen een mogelijke soort, categorie en uitleg. Bekende inkomenswoorden tellen alleen als salaris wanneer het bedrag positief is. Bij onvoldoende aanwijzingen gebruikt de app **Overig** en zegt hij dat de match onzeker is. Jouw categoriecorrecties blijven in de lokale browseropslag.

Dit is een uitlegbare lokale herkenner, geen generatief AI-model. Hij raadt geen onbekende handelaar bij elkaar en gebruikt geen cloud-API. Daardoor kunnen sommige betalingen verkeerd of niet herkend worden. Controleer de uitkomst zelf.

## Wat wordt gecontroleerd?

- CSV-scheidingsteken en datum-/bedragkoppen;
- leesbare bedragen en datums, met melding bij rijen die niet goed gelezen worden;
- mogelijk identieke dubbele transacties (de app verwijdert deze nooit automatisch);
- ontbrekende tegenpartij/omschrijving of saldo-kolom;
- transacties die in de algemene categorie **Overig** staan;
- herhaalde betalingen, als mogelijke maar niet bevestigde abonnementen.

Uitgaven en bespaarschattingen gebruiken de 30 dagen tot de nieuwste transactiedatum in het bestand. Een mogelijk terugkerende betaling is geen bewijs dat het een abonnement is. Een ontbrekende saldo-kolom betekent dat de app het actuele banksaldo niet kan afleiden.

## Publiceren met GitHub Pages

Je kunt dit project gratis als website publiceren vanuit een **public** GitHub-repository:

1. Maak een nieuwe repository op GitHub. Upload de **inhoud** van deze map zodat `index.html` rechtstreeks in de hoofdmap van de repository staat. Je kunt GitHub Desktop gebruiken of op GitHub **Add file → Upload files** kiezen.
2. Open de repository op GitHub, ga naar **Settings → Pages**.
3. Kies bij de bron **Deploy from a branch**, selecteer branch `main` en map `/(root)`, en sla op.
4. Wacht tot GitHub Pages klaar is en open de getoonde website-link.
5. In Edge: open die website, kies het menu **… → Apps → Install this site as an app** (als Edge die optie toont). De app krijgt een eigen venster en wordt offline beschikbaar na het eerste bezoek.

GitHub Pages is een openbare website. Deel of commit nooit een bank-CSV, saldo, IBAN, wachtwoord, secret of ander persoonlijk financieel bestand. Alleen de appbroncode hoort in deze repository. GitHub zoekt `index.html` in de hoofdmap van de gekozen publicatiebron.

## Privacy en beperkingen

- De gekozen CSV wordt met de browser File API gelezen en wordt niet naar deze website geüpload.
- De app haalt geen actuele transacties op en kan geen ING-overschrijvingen doen. Je moet zelf periodiek een nieuwe export downloaden.
- In de browser worden alleen je eigen categoriecorrecties opgeslagen. Je CSV blijft op je computer.
- Controleer categorieën, transacties, saldo en tips altijd zelf; de app is geen bank, boekhouder of financieel adviseur.

## Licentie

MIT. Zie [LICENSE](LICENSE).
